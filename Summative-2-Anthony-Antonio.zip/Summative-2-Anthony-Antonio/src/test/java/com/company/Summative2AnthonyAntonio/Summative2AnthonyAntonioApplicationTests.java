package com.company.Summative2AnthonyAntonio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Summative2AnthonyAntonioApplicationTests {

	@Test
	void contextLoads() {
	}

}
