package com.company.Summative2AnthonyAntonio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Summative2AnthonyAntonioApplication {

	public static void main(String[] args) {
		SpringApplication.run(Summative2AnthonyAntonioApplication.class, args);
	}

}
